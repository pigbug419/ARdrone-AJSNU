#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
//

#define SERVER_PORT 12345
#define DB_COUNT 10000
#define DB_SIZE 1024
#define BUF_SIZE 2048
#define MAX_CLIENTS 8
// db size = 10000, bytes per one element = 1024

void randgen(char* buf, int size) // for write db
{
	// generate random number sequence
	int i;
	for(i = 0; i<size; i++)
	{
		*(buf+i) = '0'+ (rand() % 10);
	}
	buf[size] = '\0';
}


void zerogen(char* buf, int size) // for write db
{
	memset(buf, '0', size);
	buf[size] = '\0';
}

int main(int argc, char **argv)
{
	// for make request
	
	FILE* tr_fp; // trace fp
	struct timeval start_time, end_time;
	int sec, usec;
	int mode; // 0 : read 1 : write
	int ret = 0;
	int element_num, element_rec;
	char data_buf[DB_SIZE+1];
	// for socket
	int sock, bytes_received;
	char send_data[BUF_SIZE];
	char recv_data[BUF_SIZE];
	
	struct sockaddr_in server_addr;
	
	srand(time(NULL));

	if(argc<2)
	{
		printf("not enough arguments, use ./(executable file name) (trace file name) (server ip) (read or write)\n");
		return -1;
	}
	
	if(!(tr_fp = fopen(argv[1], "r+")))
	{
		perror("cannot open the trace file");
		return -1;
	}

	mode = 0;
	if(argc>3) if(argv[3][0] == 'w') mode = 1;

	if((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Socket");
		ret = -1;
		goto fp_end;
	}

	memset(&server_addr, 0x0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = SERVER_PORT;
	server_addr.sin_addr.s_addr = argc<3? inet_addr("127.0.0.1"): inet_addr(argv[2]);

	if(connect(sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) == -1) {
		perror("Connect");
		ret = -1;
		goto socket_end;
	}
	// wait for activation
	read(sock, recv_data, BUF_SIZE);
	//debug
	printf("I am activated! accessing begins@\n ");

	while(fscanf(tr_fp, "%d %d", &element_num, &element_rec) >= 0)
	{
		if(mode == 0)
		{
			sprintf(send_data, "r\t%d\t%d", element_num, element_rec);
			gettimeofday(&start_time, NULL);
			write(sock, send_data, strlen(send_data));
			bytes_received = read(sock, recv_data, BUF_SIZE);
			gettimeofday(&end_time, NULL);
			//debug
			recv_data[bytes_received] = '\0';
			printf("Read received: %d: %s\n", element_num, recv_data);
		}
		else
		{
			randgen(data_buf, DB_SIZE);
			gettimeofday(&start_time, NULL);
			sprintf(send_data, "w\t%d\t%d\t%s", element_num, element_rec, data_buf);
			write(sock, send_data, strlen(send_data));
			bytes_received = read(sock, recv_data, BUF_SIZE);
			gettimeofday(&end_time, NULL);
			//debug
			recv_data[bytes_received] = '\0';
			printf("Write received: %d: %s\n", element_num, recv_data);
		}
		sec = end_time.tv_sec - start_time.tv_sec;
		usec = end_time.tv_usec - start_time.tv_usec;
		if(usec < 0){
			sec--;
			usec+=1000000;
		}
		printf("response time: %d s %d us\n", sec, usec);
	}

socket_end:
	close(sock);
fp_end:
	fclose(tr_fp);
	return ret;
}
